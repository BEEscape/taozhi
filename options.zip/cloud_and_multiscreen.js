/**
 * define MouseGestures : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function CloudAndMultiscreen() {
      OptionsPage.call(this, 'cloudAndMultiscreen', '\u9009\u9879 - \u79FB\u52A8\u3001\u4E91', 'cloudAndMultiscreenPage');
  }

  cr.addSingletonGetter(CloudAndMultiscreen);

  CloudAndMultiscreen.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
    },
  };

  return {
    CloudAndMultiscreen: CloudAndMultiscreen
  };
});
