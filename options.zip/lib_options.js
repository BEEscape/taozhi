﻿/**
 * define Speedup Options : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function LibOptions() {
    OptionsPage.call(this, 'lib', '选项 - 实验室', 'libPage');
  }

  cr.addSingletonGetter(LibOptions);

  LibOptions.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function() {
      OptionsPage.prototype.initializePage.call(this);

      Preferences.getInstance().addEventListener('se.browser.enable_kandatu', function(e) {
        $$('[pref="' + e.type + '"]').parents('.checkbox').nextAll('.sub-item').find('input,button').attr('disabled', !e.value.value);
      });

      Preferences.getInstance().addEventListener('se.browser.mobile.autosync', function(e) {
        $$('[pref="' + e.type + '"]').parents('.checkbox').nextAll('.sub-item').find('input,button').attr('disabled', !e.value.value);
      });

      $('manage-kandatu-list').onclick = function(event) {
        OptionsPage.navigateToPage("manageKandatuList");
      };
      $('button_save_images').onclick = function(event) {
        chrome.send('selectSaveImagesQuicklyLocation');
        window.userGesture = true;
      };
    },
  };

  return {
    LibOptions: LibOptions
  };
});