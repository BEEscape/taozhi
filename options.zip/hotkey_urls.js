/**
 * define MouseGestures : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function HotkeyUrls() {
      OptionsPage.call(this, 'hotkeyurls', '\u9009\u9879 - \u70ED\u952E\u7F51\u5740', 'hotkeyurlsPage');
  }

  cr.addSingletonGetter(HotkeyUrls);

  HotkeyUrls.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
    },
  };

  return {
    HotkeyUrls: HotkeyUrls
  };
});
