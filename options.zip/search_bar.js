/**
 * define SearchBar : Third Party UI Options Page
 * 
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;
  
  function SearchBar() {
      OptionsPage.call(this, 'searchbar', '\u9009\u9879 - \u641C\u7D22\u680F', 'searchBarPage');
    }
  
  cr.addSingletonGetter(SearchBar);
  
  SearchBar.prototype = {
    __proto__: options.OptionsPage.prototype,
    
    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
	  //
    }
  };
  
  return {
      SearchBar: SearchBar
    };
});

