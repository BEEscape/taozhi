/**
 * define Speedup Options : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function SpeedupOptions() {
      OptionsPage.call(this, 'speedup', '\u9009\u9879 - \u4F18\u5316\u52A0\u901F', 'speedupPage');
  }

  cr.addSingletonGetter(SpeedupOptions);

  SpeedupOptions.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function() {
      OptionsPage.prototype.initializePage.call(this);

      Preferences.getInstance().addEventListener('se.browser.prerender_url_under_mouse.enable', function(e) {
        $$('[pref="' + e.type + '"]').parents('.checkbox').nextAll('.sub-item').find('input,button').attr('disabled', !e.value.value);
      });

      Preferences.getInstance().addEventListener('download.use_thunder_p2sp', function(e) {
        $$('[pref="' + e.type + '"]').parents('.checkbox').nextAll('.sub-item').find(':checkbox,button').attr('disabled', !e.value.value);
      });

      $$('[pref="se.browser.prerender_url_under_mouse.text_limit"]').bind('change', function(){
        if (this.value < 5) {
          this.value = 5;
        }
        if (this.value > 1000) {
          this.value = 1000;
        }
      });
    },
  };

  return {
    SpeedupOptions: SpeedupOptions
  };
});
